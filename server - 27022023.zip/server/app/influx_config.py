bucket="terra-sample-bucket"
org = "Dev Team"
token = "iJbES9nOBBkQyOQ4kTABES3w4MI2eDjbrr5A8WQam9YpDHOSBTU3Bd6_svWnevJrDoG88f-tY9RNl8-euRbZpQ=="
url="https://eu-central-1-1.aws.cloud2.influxdata.com"

# To read from the local database
# bucket="sample_bucket"
# org = "terra"
# token = "p_TtbpguktSb1bxVYYxjsbgqB2NMacmXl5BV3hmV-o50qlW81DwiBdo1FihnqVKt5O7eBRCKHx1gJMWxT9HyHg=="
# url="http://localhost:8086"

import influxdb_client
from influxdb_client.client.write_api import SYNCHRONOUS

# bucket="sample_bucket"
# org = "terra"
# token = "p_TtbpguktSb1bxVYYxjsbgqB2NMacmXl5BV3hmV-o50qlW81DwiBdo1FihnqVKt5O7eBRCKHx1gJMWxT9HyHg=="

# # Store the URL of your InfluxDB instance
# url="http://localhost:8086"

bucket="terra-sample-bucket"
org = "Dev Team"
token = "iJbES9nOBBkQyOQ4kTABES3w4MI2eDjbrr5A8WQam9YpDHOSBTU3Bd6_svWnevJrDoG88f-tY9RNl8-euRbZpQ=="

# Store the URL of your InfluxDB instance
url="https://eu-central-1-1.aws.cloud2.influxdata.com"

# Instantiate the client
client = influxdb_client.InfluxDBClient(
   url=url,
   token=token,
   org=org
)

query = 'from(bucket:"terra-sample-bucket")\
|> range(start: -20m)\
|> filter(fn:(r) => r._measurement == "my_measurement")\
|> filter(fn:(r) => r._field == "temperature")'

query_api = client.query_api()
result = query_api.query(org=org, query=query)

# print(result)

results = []

for table in result:
    for record in table.records:
        results.append((record.get_time(), record.get_field(), record.get_value(), record.values.get('location')))

print(results)
import influxdb_client
from influxdb_client.client.write_api import SYNCHRONOUS

bucket="terra-sample-bucket"
org = "Dev Team"
token = "iJbES9nOBBkQyOQ4kTABES3w4MI2eDjbrr5A8WQam9YpDHOSBTU3Bd6_svWnevJrDoG88f-tY9RNl8-euRbZpQ=="

# Store the URL of your InfluxDB instance
url="https://eu-central-1-1.aws.cloud2.influxdata.com"

# Instantiate the client
client = influxdb_client.InfluxDBClient(
   url=url,
   token=token,
   org=org
)

# Synchronous writes should take care of the locking issue if it exists
write_api = client.write_api(write_options=SYNCHRONOUS)

t_1 = influxdb_client.Point("my_measurement").tag("location", "top").field("temperature", 27.3)
t_2 = influxdb_client.Point("my_measurement").tag("location", "middle").field("temperature", 32.3)
t_3 = influxdb_client.Point("my_measurement").tag("location", "bottom").field("temperature", 25.3)

write_api.write(bucket=bucket, org=org, record=t_1)
write_api.write(bucket=bucket, org=org, record=t_2)
write_api.write(bucket=bucket, org=org, record=t_3)